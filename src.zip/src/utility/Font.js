export default Fonts = {
  bold: "Metropolis-Bold",
  extraBold: "Metropolis-ExtraBold",
  semiBold: "Metropolis-SemiBold",
  light: "Metropolis-Light",
  regular: "Metropolis-Regular",
  medium: "Metropolis-Medium",
  thin: "Metropolis-Thin",
};