export default Sizes = {
  small: 10,
  regular: 12,
  medium: 14,
  semiLarge: 16,
  large: 18,
  extraLarge: 20,
  extraSmall: 8,
  double: 22,
  extraDouble: 24,
  extraDouble2x: 40,
};
